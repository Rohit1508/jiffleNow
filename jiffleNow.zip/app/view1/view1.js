'use strict';
angular.module('myApp.view1', ['ngRoute'])

  .config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/view1', {
      templateUrl: 'view1/view1.html',
      controller: 'View1Ctrl'
    });
  }])

  .controller('View1Ctrl', ['$scope', '$http', '$rootScope', '$timeout', function ($scope, $http, $rootScope,$timeout) {
    $scope.data;
    $scope.questionText;
    $scope.counter = 0;
    $scope.disable = 0;
    $scope.numberOfQuestion;
    $scope.answers = {};
    $scope.answerSheet;
    $scope.selectedOption;
    $scope.score = 0;
    var _$scope = $scope;
    _$scope.data;
    $scope.alert1 = () => {
      $http.get('https://cdn.rawgit.com/santosh-suresh/39e58e451d724574f3cb/raw/784d83b460d6c0150e338c34713f3a1c2371e20a/assignment.json').then((response) => {
        _$scope.data = response.data;
        _$scope.numberOfQuestion = _$scope.data.length;
        _$scope.refreshQuestion();
      });
    }

    $scope.updateAnswer = () => {
      $scope.answers[$scope.counter] = $scope.selectedOption;
    }

    $scope.next = () => {
      if ($scope.counter < 7) {
        $scope.updateAnswer();
        $scope.selectedOption = '';
        if ($scope.counter < $scope.numberOfQuestion - 1) {
          $scope.counter++;
          $scope.refreshQuestion();
        }
      }
      if ($scope.counter == 7) {
        $scope.updateAnswer();
        $scope.disable = 1;
      }

    }
    $scope.refreshQuestion = () => {

      $scope.options = [];
      $scope.question = $scope.data[$scope.counter];
      $scope.questionText = $scope.question.text;
      for (let option of $scope.question.options) {
        $scope.options.push(option);
      }
    }
    $scope.resetScore = () => {
      $scope.score = 0;
    }
    $scope.submit = () => {
      $scope.resetScore();
      let tempResult = $scope.answers;
      let answerSheet = $scope.data.map((data) => {
        return data.answer;
      });
      for (let i = 0; i < $scope.numberOfQuestion; i++) {
        if (tempResult[i] === answerSheet[i]) {
          $scope.score++;
        }
      }
    }
    $scope.close = function(){
      $timeout(()=>{
        window.location = "#!/view2";
      },500)
      
}
  }]);